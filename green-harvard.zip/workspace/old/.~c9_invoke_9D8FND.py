from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session, url_for, jsonify
from flask_session import Session
from passlib.apps import custom_app_context as pwd_context
from tempfile import gettempdir
import random

import helpers
from helpers import *

# configure application
app = Flask(__name__)

# ensure responses aren't cached
if app.config["DEBUG"]:
    @app.after_request
    def after_request(response):
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Expires"] = 0
        response.headers["Pragma"] = "no-cache"
        return response

# custom filter
app.jinja_env.filters["usd"] = usd

# configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = gettempdir()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# configure CS50 Library to use SQLite database
db = SQL("sqlite:///info.db")

@app.route("/")
@login_required
def index():
    """Homepage of index"""
    return render_template("index.html")
    
@app.route("/about")
def about():
    """About page outlining goals and ideas behind project"""
    return render_template("about.html")

@app.route("/tasks")
@login_required 
def tasks():
    """Add tasks and update dynamically"""
    #if request.method == "GET":
        
        # get info from the URL
        # ask = request.args.get("task")
        # print(task)
        
        # id = db.execute("SELECT id FROM tasks WHERE task LIKE :task", task=task)
        # db.execute("UPDATE done FROM tasks WHERE id LIKE :id", id=id)
        
    return render_template("leader.html")

@app.route("/myinfo")
@login_required 
def myinfo():
    """Displays graph info about own dorm and yard"""
    
    # dorm info (FROM SEARCH: CONSOLIDATE LATER FOR READABILITY AND EASE OF EDITING <3 )
    dorminfo = db.execute("SELECT dorm FROM users WHERE id=:id", id=session["user_id"])
    mydorm = dorminfo[0]["dorm"]

    useinfo = db.execute("SELECT * FROM energy2016 WHERE dorm LIKE :dorm", dorm=mydorm)
    print(useinfo)
    # piechart values
    electric = useinfo[0]["use_7"]
    naturalgas = useinfo[1]["use_7"]
    steam = useinfo[2]["use_7"]
        
    # generate piechart
    piechart = helpers.piechart(electric, naturalgas, steam)
        
    elecarray = [None] * 12
    
    for x in range(0, 12):
        word = "use_" + str(x+1)
        if x < 6:
            elecarray[x+6] = useinfo[0][word]
        else:
            elecarray[x-6] = useinfo[0][word]

    # generate barchart
    barchart = helpers.barchart(elecarray)
    
    elecarray2 = [None] * 13
        
    for x in range(0, 13):
        if x == 0:
            elecarray2[x] = mydorm
        elif x < 6:
            word = "use_" + str(x)
            elecarray2[x+7] = useinfo[0][word]
        else:
            word = "use_" + str(x)
            elecarray2[x-5] = useinfo[0][word]
                
    # generate table
    table = helpers.table(elecarray2)
    
    # -------------------------------------------------------------- 
    # yard code starts here (can create function later to make code concise/easily edited)
    
    ivy = ['Apley', 'Hollis', 'Holworthy', 'Lionel', 'Mower', 'Stoughton', 'Straus']
    crimson = ['Greenough','Hurlbut', 'Pennypacker', 'Wigglesworth']
    elm = ['Grays', 'Matthews', 'Weld']
    oak = ['Canaday', 'Thayer']
    
    if mydorm in ivy:
        dorm = ivy
        hyard = "Ivy"
    elif mydorm in crimson: 
        dorm = crimson 
        hyard = "Crimson"
    elif mydorm in elm: 
        dorm = elm 
        hyard = "Elm"
    elif mydorm in oak: 
        dorm = oak 
        hyard = "Oak"

    use = db.execute("SELECT * FROM energy2016 WHERE type = 'Electric (kWh)'")
    
    store = [None] * len(dorm)
    
    # query database for username
    for x in range(0, len(dorm)-1):
        useinfo2 = db.execute("SELECT * FROM energy2016 WHERE dorm LIKE :dorm AND type = 'Electric (kWh)'", dorm=dorm[x])
        store[x] = useinfo2[0]["use_7"]
        print(dorm[x])
        
    colours = [None] * len(dorm)
    
    for i in range(0, len(dorm)-1):
        a = str(random.randrange(256)) + ","
        b = str(random.randrange(256)) + ","
        c = str(random.randrange(256))
        colours[i] = "rgb("+ a + b + c +")"
        
    # generate piechart
    piechart2 = helpers.yardpie(dorm, store, colours)

    # render results
    return render_template("myinfo.html", chart=piechart, barchart=barchart, table=table, chart2=piechart2, hyard=hyard)

# create pie graph for different dorms in a yard
@app.route("/yard", methods=["GET", "POST"])
@login_required
def yard():
    """Search for places that match query."""
    
    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        
        # yeah, yeah this is super messy - will clean soon! :) 
        ivy = ['Apley', 'Hollis', 'Holworthy', 'Lionel', 'Mower', 'Stoughton', 'Straus']
        crimson = ['Greenough','Hurlbut', 'Pennypacker', 'Wigglesworth']
        elm = ['Grays', 'Matthews', 'Weld']
        oak = ['Canaday', 'Thayer']
        
        dorm = [None] * 8
            
        if request.form.get("yard") == 'Ivy':
            dorm = ivy 
        elif request.form.get("yard") == "Crimson":
            dorm = crimson
        elif request.form.get("yard") == "Elm":
            dorm = elm
        elif request.form.get("yard") == "Oak":
            dorm = oak
        
        use = db.execute("SELECT * FROM energy2016 WHERE type = 'Electric (kWh)'")

        store = [None] * len(dorm)
        
        # query database for username
        for x in range(0, len(dorm)-1):
            useinfo = db.execute("SELECT * FROM energy2016 WHERE dorm LIKE :dorm AND type = 'Electric (kWh)'", dorm=dorm[x])
            store[x] = useinfo[0]["use_7"]
            print(dorm[x])

        print(useinfo)
        
        colours = [None] * len(dorm)
        
        for i in range(0, len(dorm)-1):
            a = str(random.randrange(256)) + ","
            b = str(random.randrange(256)) + ","
            c = str(random.randrange(256))
            colours[i] = "rgb("+ a + b + c +")"
            
        # generate piechart
        piechart = helpers.yardpie(dorm, store, colours)

        # render results
        return render_template("yarddisplay.html", chart=piechart, hyard=request.form.get("yard"))

    else:
        # set up some list that has all the dorms
        return render_template("yard.html")

# display dorm info --> piegraph of energy type & annual graphs
@app.route("/search", methods=["GET", "POST"])
def search():
    """Search for places that match query."""
    
    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # query database for username
        useinfo = db.execute("SELECT * FROM energy2016 WHERE dorm LIKE :dorm", dorm=request.form.get("dorm"))

        # piechart values
        electric = useinfo[0]["use_7"]
        naturalgas = useinfo[1]["use_7"]
        steam = useinfo[2]["use_7"]
        
        # electric = [None] * 12
        # naturalgas = [None] * 12
        # steam = [None] * 12
        
        # for x in range(0, 12):
        #     word = "use_" + str(x+1)
        #     electric[x] = int(useinfo[0][word])
        #     naturalgas[x] = int(useinfo[1][word])
        #     steam[x] = int(useinfo[2][word])
            
        # electricsum = sum(electric)
        # naturalsum = sum(natural)
        
        # generate piechart
        piechart = helpers.piechart(electric, naturalgas, steam)
        
        elecarray = [None] * 12
        
        for x in range(0, 12):
            word = "use_" + str(x+1)
            if x < 6:
                elecarray[x+6] = useinfo[0][word]
            else:
                elecarray[x-6] = useinfo[0][word]

        # generate barchart
        barchart = helpers.barchart(elecarray)
        
        elecarray2 = [None] * 13
        
        for x in range(0, 13):
            if x == 0:
                elecarray2[x] = request.form.get("dorm")
            elif x < 6:
                word = "use_" + str(x)
                elecarray2[x+7] = useinfo[0][word]
            else:
                word = "use_" + str(x)
                elecarray2[x-5] = useinfo[0][word]
                
        # generate table
        table = helpers.table(elecarray2)
        

        # render results
        return render_template("display.html", chart=piechart, barchart=barchart, table=table, dorm=request.form.get("dorm"))

    else:
        # set up some list that has all the dorms
        return render_template("search.html")

# compare dorm/per capita to country       
@app.route("/search2", methods=["GET", "POST"])
def search2():
    """Search for places that match query."""
    
    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
         
        # ensure username was submitted
        if not request.form.get("dorm"):
            return apology("must provide dorm")
            
        if not request.form.get("country"):
            return apology("must provide Country")

            
        # query database for dorm information
        dorminfo = db.execute("SELECT * FROM energy2016 WHERE dorm LIKE :dorm", dorm=request.form.get("dorm"))
        
        # query database for username
        countryinfo = db.execute("SELECT * FROM world WHERE country LIKE :country", country=request.form.get("country"))
        print(countryinfo)
        
        # generate piechart

        dormarray = [None] * 12
        
        for x in range(0, 12):
            word = "use_" + str(x+1)
            dormarray[x] = int(dorminfo[0][word])
        
        sumdorm = helpers.pc(request.form.get("dorm"),sum(dormarray))
        cinfo = countryinfo[0]["energy_2013"]

        # generate comparison barchart
        countrycomp = helpers.countrychart(request.form.get("dorm"), request.form.get("country"), sumdorm, cinfo)

        # render results
        return render_template("display2.html", country=countrycomp, hdorm=request.form.get("dorm"), hcountry=request.form.get("country"))

    else:
        # set up some list that has all the dorms
        return render_template("search2.html")

# compare dorm to dorm per capita usage
@app.route("/search3", methods=["GET", "POST"])
def search3():
    """Search for places that match query."""
    
    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        error = ""
        
        # ensure inputted dorms are different 
        if request.form.get("dorm") == request.form.get("dorm2"):
            error = "Sorry! Please provide 2 different dorms"
            error_len = len(error)
            return render_template("search3.html", error=error, error_len=error_len)
            
        # query database for info on dorm
        useinfo = db.execute("SELECT * FROM energy2016 WHERE dorm LIKE :dorm", dorm=request.form.get("dorm"))
        # query database for info on dorm2
        useinfo2 = db.execute("SELECT * FROM energy2016 WHERE dorm LIKE :dorm", dorm=request.form.get("dorm2"))
        
        elecarray2 = [None] * 13
        
        for x in range(0, 13):
            if x == 0:
                elecarray2[x] = request.form.get("dorm")
            elif x < 6:
                word = "use_" + str(x)
                elecarray2[x+6] = helpers.pc(request.form.get("dorm"),useinfo2[0][word])
            else:
                word = "use_" + str(x)
                elecarray2[x-6] = helpers.pc(request.form.get("dorm"),useinfo2[0][word])
                
        # second dorm into
        elecarray3 = [None] * 12
        
        for x in range(0, 12):
            word = "use_" + str(x+1)
            if x < 6:
                elecarray3[x+6] = helpers.pc(request.form.get("dorm2"),useinfo2[0][word])
            else:
                elecarray3[x-6] = helpers.pc(request.form.get("dorm2"),useinfo2[0][word])

        # generate comparison barchart
        compchart = helpers.comparebar(request.form.get("dorm"), elecarray2, request.form.get("dorm2"), elecarray3)

        # render results
        return render_template("display3.html", compchart=compchart, hdorm=request.form.get("dorm"), hdorm2=request.form.get("dorm2"), error_len=0)

    else:
        # set up some list that has all the dorms
        return render_template("search3.html", error_len=0)
    
@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in."""

    # forget any user_id
    session.clear()

    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username")

        # ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password")

        # query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("username"))

        # ensure username exists and password is correct
        if len(rows) != 1 or not pwd_context.verify(request.form.get("password"), rows[0]["hash"]):
            return apology("invalid username and/or password")

        # remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # redirect user to home page
        return redirect(url_for("index"))

    # else if user reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")

@app.route("/logout")
def logout():
    """Log user out."""

    # forget any user_id
    session.clear()

    # redirect user to login form
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user."""
    
    # forget any user_id
    session.clear()
    
    # if user reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        error = ""
        
        # ensure text fields submittted 
        if not request.form.get("username"):        #HEY-CHECK: newlines to work in alert!! 
            error += "Must provide username \n" 
        if not request.form.get("password"):
            error += "Must provide password \n"
        if not request.form.get("confirmpassword"):
            error += "Must confirm password \n"
        
        # ensure passwords match 
        if not request.form.get("password") == request.form.get("confirmpassword"):
            error += "Passwords do not match \n"
        
        # verify username doesn't already exist 
        rows = db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("username"))
        if len(rows) == 1:
            error += "Username already taken \n"
        
        # reload login page with message if some input(s) is/are invalid 
        if len(error) > 0: 
            return render_template("register.html", error=error, error_len=len(error))
            
        # all inputs are valid, store info into database 
        else:      
            # hash the password 
            hash = pwd_context.encrypt(request.form.get("password"))
    
            # put data for new user into database 
            rows = db.execute("INSERT INTO users (id, username, hash, dorm) VALUES(NULL, :username, :hash, :dorm)", 
                    username=request.form.get("username"), 
                    hash = hash, 
                    dorm=request.form.get("dorm"))
            
            # remember which user has logged in
            session["user_id"] = rows
    
            # redirect user to home page
            flash("You were successfully registered")
            return redirect(url_for("index"))

    # else if user reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("register.html", error_len=0)